import './footer-ini.js';
import './navbar-ini.js';
import './note-input.js';
import './note-item.js';
