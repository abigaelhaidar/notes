class AppBar extends HTMLElement {
  constructor() {
      super();
      const shadow = this.attachShadow({ mode: 'open' });
      const title = this.getAttribute('title') || 'NOTE-APP';
      const navbar = document.createElement('div');
      navbar.setAttribute('class', 'navbar');

      navbar.innerHTML = `
          <div>
              <img src="./Asset/IMG/logo.png" alt="logo">
          </div>
          <h1>${title}</h1>
      `;

      const style = document.createElement('style');
      style.textContent = `
          .navbar {
              display: flex;
              justify-content: space-between;
              align-items: center;
              background-color: #A66E38;
              position: fixed;
              top: 0;
              width: 100%;
              height: 100px;
              padding: 0 20px;
              box-sizing: border-box;
              z-index: 10; /* Menempatkan navbar di atas elemen lain */
          }

          .navbar img {
              height: 80px;
          }

          .navbar h1 {
              flex-grow: 1;
              text-align: center;
              color: white;
              font-size: 2rem;
              margin: 0;
              margin-left: -70px;
          }
      `;

      shadow.appendChild(style);
      shadow.appendChild(navbar);
  }
}

customElements.define('app-bar', AppBar);
