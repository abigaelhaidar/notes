class FooterBar extends HTMLElement {
  constructor() {
    super();
    const shadow = this.attachShadow({ mode: 'open' });
    const footerText = this.getAttribute('footer-text') || '2024 - My Notes';
    const footer = document.createElement('footer');
    footer.setAttribute('class', 'footer');

    footer.innerHTML = `
      <p>${footerText}</p>
      <div class="footer-links">
        <a href="#">Privacy Policy</a> | 
        <a href="#">Terms of Service</a>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      .footer {
        background-color: #A66E38;
        color: white;
        text-align: center;
        padding: 20px 0;
        width: 100%;
        margin-top: auto; /* Pastikan footer berada di bawah konten */
      }
      .footer p {
        margin: 0;
        font-size: 14px;
      }
      .footer-links {
        margin-top: 5px;
      }
      .footer-links a {
        color: white;
        text-decoration: none;
        margin: 0 5px;
      }
      .footer-links a:hover {
        text-decoration: underline;
      }
    `;

    // Menambahkan gaya dan elemen ke shadow DOM
    shadow.appendChild(style);
    shadow.appendChild(footer);
  }
}

customElements.define('footer-bar', FooterBar);
